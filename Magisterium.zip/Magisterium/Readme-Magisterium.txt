        The Magisterium
        Version 0.5

Firstly, many thanks to the modders out there who spend their time helping first time modders
like myself. Cannot stress how helpful it has been to have the resources available that are
out there. Particularly like to thank DnD Detective for his Youtube videos, which really
made my first steps in modding that much clearer.

Contents

1. Introduction
2. Installation
3. General Information
4. Frequently Asked Questions
5. Credits
6. Legal Information

----------------
1. Introduction
----------------

The Magisterium is really two mods in one. Firstly, there is Casterlynne, a cleric of Mystra
who can be found early on at the Friendly Arms Inn and can be used as a traveling companion
during the first few chapters before she leaves to continue her journey south to Amn.

The second part of the mod is what was initially called the "Oren Quest" and is designed to
make the game easier to "role play" as an evil character. I always struggle with the idea that
an "evil" character would bother with some of the BG quests. Why would an evil character care
if Mirianne found out what happened to her husband or why would they return the Colquetle
amulet to the family? Truth is, they would only do so if they had a reason, a big enough reward
that was offered to them up front and thats not the case. So, the mod introduces a new
non-playable NPC called Oren who belongs to the Thiefs Guild in Baldurs Gate and is temporarily 
based in Beregost. She will offer evil aligned characters a chance to earn the rewards from
several quests without going against alignment and in some cases, incurring the reputation 
increases that can affect evil NPCs in the group.


----------------
2. Installation
----------------

Make sure that you have obtained and installed the latest official Bioware patch.
Install the official patch BEFORE installing any unofficial modifications.


To install the mod, unpack the archive into your BG2 directory and run
Setup-*****.exe.

Once you see the Readme, the installation is complete.

To reinstall or uninstall the mod, run Setup-*****.exe in your game directory.

-----------------------
3. General Information
-----------------------

This mod adds Casterlynne as a NPC. She can be found in the temple at the Friendly Arms Inn
from chapter one until chapter four only. You do not need to start a new game to get her 
into your party. She only has one restriction with regards to joining or staying in the party.  
Casterlynne is a cleric of Mystra and will not align herself with followers of Shar.  She will not 
join if PC is a follower of Shar or Viconia is in the group.  Also, if she is in the group and 
Viconia joins you will be confronted with a choice. She has a full friendship with the PC, 
player-initiated dialogue, banters with several Bioware NPCs, a number of interjections, character 
reactions and other scenery dialogue. She is a devout follower of Mystra, so there are no plans
for a romance - she has but one love.

Oren can be first encountered in Candlekeep, where she will either introduce herself to evil-minded
PCs - or just walkaway! She can then be found in Beregost, around the back of Firebeards house. From
there, she will offer a very easy job, which will be the beginning of her interactions with the PC.

------------------------------
4. Frequently Asked Questions
------------------------------

Q: Where is she?
A: She can be found in the temple at the Friendly Arms Inn from chapter one until chapter four only.

Q: Why cant I remove her ring?
A: Its hermost prized possesion. She is a devour follower of Mystra. Also this ring will have more
to come, so its necesary for her to keep it at all times. (Hint, see next question!

Q: Why does she leave after arriving at Baldurs Gate?
A: Castelynne is on a mission to help with the establishment of a new temple in Amn and that is more
important to her than anything. She leaves to help with that task and will retun in BG2 in a future
update to the mod. The BG2 part is planned to include her new kit, much updated and more powerful 
ring(thats why it cant be removed!) and a quest linked to a new area which will be the temple itself.

Q: Oren doesnt offer me any jobs?
A: Remember that this part of the mod is only for LE, NE or CE aligned characters. Apart from that
there are no restrictions.

Q: The Magisterium? 
A: Yes, the name of a book that Oren requires and Casterlynne sees as too valuable to be in the hands
of a theives guild.  It will cause problems if Casterylnne is in your group and you take on the task 
and those problems will affect how the storyline evolves later on, after Casterlynne leaves.


Q: Where is the Portrait from, it looks familiar?
A:

Q: I am a modder and I want to steal your code.
A: Go ahead, but this is my first mod so the code is very simple perhaps not the best example you can
find or most elegant/effecient way of doing things.

Q: Did you steal my code!!!
A: Yes, it is possible so thankyou is due to -
* DnD Detective
* Everyone at Gibberlings 3 and Pocket Plane for their excellent and incredibly helpful modding 
communities, tips and guides
* The people behind the Branwen BG2 npc mod - I picked that apart so much, so thank you!
* and once I knew what I was doing its fair to say that studying mods by Skitia/The Artisan really
helped me understand even more and put togethor some of the coding for this mod.


-----------
5. Credits
-----------

John Walker (JWMadrid or JBMadrid depending on site)
Writer/Programmer


Mod was created with the following software:
ConTEXT		http://www.gibberlings3.net/tools/
Near Infinity   http://infexp.sourceforge.net
WeiDU		http://www.weidu.org

-------------------
6. Version History
-------------------

Version 0.5
- Initial test release

---------------------
7. Legal Information
---------------------

=================================================================================
BALDUR'S GATE II: SHADOWS OF AMN Developed and � 2000 BioWare Corp. All Rights
Reserved. BALDUR'S GATE II: THRONE OF BHAAL Developed and � 2001 BioWare
Corp. All Rights Reserved. Baldur's Gate, Shadows of Amn, Tales of the Sword
Coast, Forgotten Realms, the Forgotten Realms logo, Advanced Dungeons & Dragons,
the AD&D logo, TSR and the TSR logo, and the Wizards of the Coast logo, are
trademarks of the Wizards of the Coast, Inc., a subsidiary of Hasbro, Inc., and
are used by Interplay Entertainment Corp. under license. All Rights Reserved.
BioWare, the BioWare Infinity Engine and the BioWare logo are the trademarks of
BioWare Corp. All Rights Reserved. Black Isle Studios and the Black Isle Studios
logo are trademarks of Interplay Entertainment Corp. All Rights Reserved.
Exclusively licensed and distributed by Interplay Entertainment Corp. All other
trademarks and copyrights are property of their respective owners.
=================================================================================

=================================================================================
The Magisterium MOD for Baldur's Gate � 2023 John Walker, is not
developed, supported, or endorsed by BioWare, Black Isle Studios, Interplay
Entertainment Corp., or the Wizards of the Coast. All other trademarks and
copyrights are property of their respective owners.
=================================================================================

=================================================================================
REDISTRIBUTION NOTE: The Magisterium MOD was created to be freely enjoyed by all 
Baldur's Gate players and picked apart by all Baldur's Gate modders. Please, don't
mirror The Magisterium MOD anywhere, but feel free to use her code as a base for 
your own mods.
=================================================================================