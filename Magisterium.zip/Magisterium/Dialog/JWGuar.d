BEGIN JWGuar

IF ~NumberOfTimesTalkedTo(0)~ THEN BEGIN 4
SAY @150
    ++ @151 GOTO 4.1
END

IF ~~ THEN BEGIN 4.1
SAY @152
= @153
= @154
    ++ @155 GOTO 4.2
END

IF ~~ THEN BEGIN 4.2
SAY @156
IF ~~ THEN DO ~EraseJournalEntry(@20) AddJournalEntry(@21,QUEST) SetGlobal("JWGuardTalk","GLOBAL",1)~EXIT
END