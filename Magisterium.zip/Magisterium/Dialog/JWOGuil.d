BEGIN JWOGuil

// Main Talks

IF ~True()~ THEN BEGIN 0
SAY ~Well that was over rather quickly! How disappointing. I had hoped Alatos might put up some kind of fight!~
= ~And such a shame our mutal 'associate' did not stick around. I could use a talented mage.~
= ~As for you, well, you have proven... useful. My organisation will take over from here. I suggest you leave, whilst you can.~
++ ~Organisation?~ GOTO 1.2
END

IF ~~ THEN BEGIN 1.2
SAY ~You think this was all about you? As someone once taught me... 'Every plan casts a shadow. And there is always something moving within it'. You, <CHARNAME>, were just a small piece in a grander scheme..~
= ~For now, 'hero', our time has come to an end. Its time for you to move on. Perhaps the fates will bring us togethor again, till then....~
IF ~~ THEN DO ~SetGlobal("JWBalGuildJob","Global",3) AddexperienceParty(1000) EscapeArea()~ EXIT
END
