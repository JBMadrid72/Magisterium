BEGIN JWCastP

IF ~Global("KickedOut","LOCALS",0) !Global("JWCastRefused","GLOBAL",2)~ THEN BEGIN 0
SAY @950
++ @951 DO ~JoinParty()~ EXIT
++ @952 DO ~SetDialog("JWCastP") SetGlobal("KickedOut", "LOCALS",1)~ EXIT
END

IF ~Global("KickedOut","LOCALS",1) !Global("JWCastRefused","GLOBAL",2)~ THEN BEGIN 1
SAY @953
++ @954 DO ~JoinParty() SetDialog("JWCast") SetGlobal("KickedOut","LOCALS", 0)~ EXIT
++ @955 EXIT
END

IF ~Global("KickedOut","LOCALS",0) Global("JWCastRefused","GLOBAL",2)~ THEN BEGIN 2
SAY @980
++ @981 GOTO 4
++ @982 GOTO 5
END

IF ~Global("KickedOut","LOCALS",1)Global("JWCastRefused","GLOBAL",2)~ THEN BEGIN 3
SAY @980
++ @981 GOTO 4
++ @982 GOTO 5
END

IF ~~ THEN BEGIN 4
SAY @983
= @984
IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 5
SAY @985
= @986
IF ~~ THEN DO ~JoinParty()~ EXIT
END
