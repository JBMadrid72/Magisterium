BEGIN JWCastJ

//////////////////////////////////////////////////
// TIMED TALKS SYSTEM
//////////////////////////////////////////////////

// Talk 1

IF ~Global("JWCastTalk","GLOBAL",1)~ THEN BEGIN t1
  SAY @200
  ++ @201 GOTO t1b
END

IF ~~ THEN BEGIN t1b
  SAY @202
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 2
IF ~Global("JWCastTalk","GLOBAL",3)~ THEN BEGIN t2
  SAY @203
  ++ @204 GOTO t2b
END

IF ~~ THEN BEGIN t2b
  SAY @205
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 3  (FIXED HERE)
IF ~Global("JWCastTalk","GLOBAL",5)~ THEN BEGIN t3
  SAY @206
  ++ @207 GOTO t3b
END

IF ~~ THEN BEGIN t3b
  SAY @208
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 4
IF ~Global("JWCastTalk","GLOBAL",7)~ THEN BEGIN t4
  SAY @209
  ++ @210 GOTO t4b
END

IF ~~ THEN BEGIN t4b
  SAY @211
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 5
IF ~Global("JWCastTalk","GLOBAL",9)~ THEN BEGIN t5
  SAY @212
  ++ @213 GOTO t5b
END

IF ~~ THEN BEGIN t5b
  SAY @214
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 6
IF ~Global("JWCastTalk","GLOBAL",11)~ THEN BEGIN t6
  SAY @215
  ++ @216 GOTO t6b
END

IF ~~ THEN BEGIN t6b
  SAY @217
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 7
IF ~Global("JWCastTalk","GLOBAL",13)~ THEN BEGIN t7
  SAY @218
  ++ @219 GOTO t7b
END

IF ~~ THEN BEGIN t7b
  SAY @220
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 8
IF ~Global("JWCastTalk","GLOBAL",15)~ THEN BEGIN t8
  SAY @221
  ++ @222 GOTO t8b
END

IF ~~ THEN BEGIN t8b
  SAY @223
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 9
IF ~Global("JWCastTalk","GLOBAL",17)~ THEN BEGIN t9
  SAY @224
  ++ @225 GOTO t9b
END

IF ~~ THEN BEGIN t9b
  SAY @226
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 10
IF ~Global("JWCastTalk","GLOBAL",19)~ THEN BEGIN t10
  SAY @227
  ++ @228 GOTO t10b
END

IF ~~ THEN BEGIN t10b
  SAY @229
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 11
IF ~Global("JWCastTalk","GLOBAL",21)~ THEN BEGIN t11
  SAY @230
  ++ @231 GOTO t11b
END

IF ~~ THEN BEGIN t11b
  SAY @232
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 12
IF ~Global("JWCastTalk","GLOBAL",23)~ THEN BEGIN t12
  SAY @233
  ++ @234 GOTO t12b
END

IF ~~ THEN BEGIN t12b
  SAY @235
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 13
IF ~Global("JWCastTalk","GLOBAL",25)~ THEN BEGIN t13
  SAY @236
  ++ @237 GOTO t13b
END

IF ~~ THEN BEGIN t13b
  SAY @238
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 14
IF ~Global("JWCastTalk","GLOBAL",27)~ THEN BEGIN t14
  SAY @239
  ++ @240 GOTO t14b
END

IF ~~ THEN BEGIN t14b
  SAY @241
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END


// Talk 15
IF ~Global("JWCastTalk","GLOBAL",29)~ THEN BEGIN t15
  SAY @242
  ++ @243 GOTO t15b
END

IF ~~ THEN BEGIN t15b
  SAY @244
  IF ~~ DO ~IncrementGlobal("JWCastTalk","GLOBAL",1)
            RealSetGlobalTimer("JWCastTimer","GLOBAL",1200)~
     EXIT
END
