BEGIN JWKayra

IF ~NumberOfTimesTalkedTo(0)~ THEN BEGIN 1
SAY @70
    = @71
    ++ @72 GOTO 1.11
    ++ @73 GOTO 1.13
END

IF ~NumberOfTimesTalkedTo(1)~ THEN BEGIN 1.05
SAY @90
    ++ @91 GOTO 1.2
    ++ @86 GOTO 1.98
END

IF ~~ THEN BEGIN 1.1
SAY @74
    = @75
    = @76
    ++ @77 GOTO 1.2
    ++ @78 GOTO 1.98
END

IF ~~ THEN BEGIN 1.11
SAY @74
    = @75
    = @76
    ++ @77 GOTO 1.2
    ++ @78 GOTO 1.98
END

IF ~~ THEN BEGIN 1.13
SAY @75
    = @76
    ++ @77 GOTO 1.2
    ++ @78 GOTO 1.98
END

IF ~~ THEN BEGIN 1.2
SAY @79
    ++ @80 GOTO 1.4
    ++ @81 GOTO 1.5
END

IF ~~ THEN BEGIN 1.4
SAY @83
= @84
    +~!Global("AttackedSilke","GLOBAL",1)~+ @85 GOTO 1.99
    +~Global("AttackedSilke","GLOBAL",1)~+ @85 GOTO 1.991
END

IF ~~ THEN BEGIN 1.5
SAY @82
= @83
= @84
    +~!Global("AttackedSilke","GLOBAL",1)~+ @85 GOTO 1.99
    +~Global("AttackedSilke","GLOBAL",1)~+ @85 GOTO 1.991
END

IF ~~ THEN BEGIN 1.98
SAY @87
IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 1.99
SAY @88
= @89
IF ~~ THEN DO ~AddJournalEntry(@20,QUEST) SetGlobal("JWKayraJob1","Global",1) EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.991
SAY @88
= @92
= @93
= @94
IF ~~ THEN DO ~AddJournalEntry(@20,QUEST) SetGlobal("JWKayraJob1","Global",1) EscapeArea()~ EXIT
END