BEGIN ~JWNOBL2~

IF ~True()~ THEN BEGIN 0
  SAY ~My dear! Common riffraff running about my house. Perhaps all of you could be so kind as to leave, at once. I'm off on important business, and I really can't have strangers stomping about my home. When I get back, please make sure that you're gone.~
  ++ ~My apologies for the intrusion, sir. We are looking for a particular book. Might I ask if your library contains a copy of The Magisterium?~  GOTO 1.1
  ++ ~Then I will get straight to the point. I'm looking for a book. The Magisterium. You have it.~ GOTO 1.5
END

IF ~StateCheck(Myself,STATE_CHARMED)~ THEN BEGIN 1
  SAY ~As a man of distinguished lineage, I rarely stoop to the common events of the peasant. I doubt that there is anything I could tell you that you would find useful. Sorry friend.~
  IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 2
  SAY ~I'll not speak a word after what you did!~
  IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 1.1
  SAY ~Indeed I do. And I see no reason why that should concern you~
  ++ ~We only wish to examine it.~ GOTO 1.2
END

IF ~~ THEN BEGIN 1.2
  SAY ~My dear fellow, you misunderstand. It is my book. I have no intention of lending it, displaying it, or allowing strangers to paw through it.~
  = ~I expect you to leave immediately or i shall call the guards.~
  IF ~~ THEN DO ~SetGlobal("JWNOBL2","Global",1) EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.5
  SAY ~That is not your concern!~
  ++ ~Well, I want the book. Hand it over!~ GOTO 1.6
END

IF ~~ THEN BEGIN 1.6
  SAY ~Absolutely not. You barge into my home, threaten me, and expect me to surrender my possessions? I will not be intimidated in my own house.~
  = ~I expect you to leave immediately or i shall call the guards.~
  IF ~~ THEN DO ~SetGlobal("JWNOBL2","Global",1) EscapeArea()~ EXIT
END


