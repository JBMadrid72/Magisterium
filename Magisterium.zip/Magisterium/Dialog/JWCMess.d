// Create JWCMess.DLG properly

BEGIN JWCMess

IF ~True()~ THEN BEGIN JWCastMess
  SAY ~Excuse me, <SIRMAAM>, would you be travelling with Casterlynne, of Waterdeep?~
IF ~~ THEN DO ~SetGlobal("JWCMess","GLOBAL",2) EscapeArea()~ EXIT
END


