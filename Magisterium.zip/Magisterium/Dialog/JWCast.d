BEGIN JWCast

//////////////////////////////////////////////////
// INTRO / JOIN
//////////////////////////////////////////////////

IF ~NumTimesTalkedTo(0)~ THEN BEGIN 1
  SAY @100
  = @101
  = @102
  ++ @104 GOTO 1.2
  ++ @105 GOTO 1.4
  ++ @106 GOTO 1.7
END

IF ~!NumTimesTalkedTo(0) !InParty(Myself)~ THEN BEGIN 1.05
  SAY @900
  = @901
  ++ @902 GOTO 1.31
  ++ @903 GOTO 1.32
  ++ @904 GOTO 1.33
  ++ @905 GOTO 1.32
END

IF ~~ THEN BEGIN 1.2
  SAY @107
  = @108
  ++ @109 GOTO 1.3
  ++ @110 GOTO 1.3
  ++ @111 GOTO 1.12
END

IF ~~ THEN BEGIN 1.3
  SAY @112
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.4
  SAY @113
  = @162
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.5
  SAY @117
  = @118
  = @119
  ++ @120 GOTO 1.14
  ++ @121 GOTO 1.15
END

IF ~~ THEN BEGIN 1.7
  SAY @123
  = @124
  ++ @125 GOTO 1.8
  ++ @126 GOTO 1.9
  ++ @127 GOTO 1.10
  ++ @128 GOTO 1.11
END

IF ~~ THEN BEGIN 1.8
  SAY @129
  = @130
  = @131
  ++ @132 GOTO 1.11
  ++ @133 GOTO 1.3
  ++ @134 GOTO 1.16
END

IF ~~ THEN BEGIN 1.9
  SAY @135
  = @136
  ++ @137 GOTO 1.17
  ++ @138 GOTO 1.18
  ++ @139 GOTO 1.19
END

IF ~~ THEN BEGIN 1.10
  SAY @140
  = @141
  ++ @142 GOTO 1.13
  ++ @143 GOTO 1.20
  ++ @144 GOTO 1.21
END

IF ~~ THEN BEGIN 1.11
  SAY @145
  = @146
  = @112
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.12
  SAY @147
  = @148
  = @112
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.13
  SAY @149
  = @118
  = @119
  ++ @120 GOTO 1.14
  ++ @121 GOTO 1.15
END

IF ~~ THEN BEGIN 1.14
  SAY @150
  = @151
IF ~~ THEN DO ~SetGlobal("JWCastJoined","GLOBAL",1) JoinParty()~ EXIT
END

IF ~~ THEN BEGIN 1.15
  SAY @152
  = @153 IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 1.16
  SAY @154
  = @112
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.17
  SAY @155
  = @156
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.18
  SAY @157
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.19
  SAY @158
  = @159
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.20
  SAY @160
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.21
  SAY @161
  = @113
  = @114
  ++ @115 GOTO 1.5
  ++ @116 GOTO 1.13
END

IF ~~ THEN BEGIN 1.31
  SAY @906
  = @907
IF ~~ THEN DO ~SetGlobal("JWCast-joined","GLOBAL",1) JoinParty()~ EXIT
END

IF ~~ THEN BEGIN 1.32
  SAY @908
  = @909 IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 1.33
  SAY @910
  = @911
IF ~~ THEN DO ~SetGlobal("JWCast-joined","GLOBAL",1) JoinParty()~ EXIT
END


//////////////////////////////////////////////////
// Location Talks
//////////////////////////////////////////////////

//// Talk 1 - Beregost, temple Lathander

IF ~Global("JWCastTempleBeregost","GLOBAL",1)~ THEN BEGIN 2.0
  SAY @180
  = @181
  ++ @182 GOTO 2.1
  ++ @183 GOTO 2.2
  ++ @184 GOTO 2.3
  ++ @185 GOTO 2.4
END


IF ~~ THEN BEGIN 2.1
  SAY @186
  ++ @187 GOTO 2.6
  ++ @188 GOTO 2.5
END


IF ~~ THEN BEGIN 2.2
  SAY @189
  = @192
  IF ~~ THEN DO ~SetGlobal("JWCastTempleBeregost","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 2.3
  SAY @190
  = @192
  IF ~~ THEN DO ~SetGlobal("JWCastTempleBeregost","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 2.4
  SAY @191
  IF ~~ THEN DO ~SetGlobal("JWCastTempleBeregost","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 2.5
  SAY @193
  = @194
  IF ~~ THEN DO ~SetGlobal("JWCastTempleBeregost","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 2.6
  SAY @192
  IF ~~ THEN DO ~SetGlobal("JWCastTempleBeregost","GLOBAL",2)~ EXIT
END


//// Talk 2 - Nashkel, Temple Helm

IF ~Global("JWCastTempleNash","GLOBAL",1)~ THEN BEGIN 3.0
  SAY @200
  = @201
  ++ @202 GOTO 3.1
  ++ @203 GOTO 3.2
  ++ @204 GOTO 3.3
  ++ @205 GOTO 3.4
END


IF ~~ THEN BEGIN 3.1
  SAY @206
  ++ @207 GOTO 3.5
  ++ @208 GOTO 3.6
  ++ @209 GOTO 3.7
  ++ @210 GOTO 3.3
END


IF ~~ THEN BEGIN 3.2
  SAY @211
  = @212
  ++ @213 GOTO 3.8
  ++ @214 GOTO 3.3
END


IF ~~ THEN BEGIN 3.3
  SAY @215
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.4
  SAY @216
  = @217
  = @219
  = @225
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.5
  SAY @218
  = @219
  = @225
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.6
  SAY @220
  = @221
  = @225
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.7
  SAY @222
  = @223
  = @224
  = @225
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.8
  SAY @226
  = @227
  ++ @228 GOTO 3.9
  ++ @229 GOTO 3.11
  ++ @230 GOTO 3.3
END


IF ~~ THEN BEGIN 3.9
  SAY @231
  ++ @232 GOTO 3.10
  ++ @233 GOTO 3.3
END


IF ~~ THEN BEGIN 3.10
  SAY @234
  = @235
  ++ @236 GOTO 3.12
  ++ @237 GOTO 3.15
  ++ @238 GOTO 3.16
END


IF ~~ THEN BEGIN 3.11
  SAY @239
  = @225
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.12
  SAY @240
  = @241
  = @242
  ++ @243 GOTO 3.13
  ++ @244 GOTO 3.14
END


IF ~~ THEN BEGIN 3.13
  SAY @245
  = @246
  = @225
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.14
  SAY @247
  = @248
  = @225
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.15
  SAY @249
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 3.16
  SAY @250
  IF ~~ THEN DO ~SetGlobal("JWCastTempleNash","GLOBAL",2)~ EXIT
END


//// Talk 3 - Talk whilst Resting

IF ~Global("JWCastRestTalk1","GLOBAL",1)~ THEN BEGIN 4.0
  SAY @269
  = @270
  ++ @271 GOTO 4.1
  ++ @272 GOTO 4.2
  ++ @273 GOTO 4.3
END


IF ~~ THEN BEGIN 4.1
  SAY @274
  ++ @275 GOTO 4.4
  ++ @276 GOTO 4.5
  ++ @277 GOTO 4.6
  ++ @278 GOTO 4.7
END


IF ~~ THEN BEGIN 4.2
  SAY @279
  ++ @280 GOTO 4.8
  ++ @281 GOTO 4.15
  ++ @282 GOTO 4.7
END


IF ~~ THEN BEGIN 4.3
  SAY @283
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.4
  SAY @284
  = 285
  ++ @286 GOTO 4.8
  ++ @287 GOTO 4.9
END


IF ~~ THEN BEGIN 4.5
  SAY @288
  ++ @289 GOTO 4.10
  ++ @290 GOTO 4.11
  ++ @291 GOTO 4.7
END


IF ~~ THEN BEGIN 4.6
  SAY @292
  = @293
  ++ @294 GOTO 4.12
  ++ @295 GOTO 4.7
END


IF ~~ THEN BEGIN 4.7
  SAY @296
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.8
  SAY @297
  = @298
  = @306
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.9
  SAY @299
  = @306
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.10
  SAY @300
  = @301
  = @306
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.11
  SAY @302
  = @303
  ++ @304 GOTO 4.12
  ++ @305 GOTO 4.7
END


IF ~~ THEN BEGIN 4.12
  SAY @307
  = @308
  = @309
  = @306
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.13
  SAY @310
  = @311
  ++ @312 GOTO 4.15
  ++ @313 GOTO 4.7
END


IF ~~ THEN BEGIN 4.14
  SAY @318
  = @319
  = @306
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.15
  SAY @314
  = @315
  ++ @316 GOTO 4.16
  ++ @317 GOTO 4.17
END


IF ~~ THEN BEGIN 4.16
  SAY @320
  = @321
  ++ @322 GOTO 4.18
  ++ @323 GOTO 4.21
END


IF ~~ THEN BEGIN 4.17
  SAY @324
  = @325
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


IF ~~ THEN BEGIN 4.18
  SAY @326
  = @327
  = @328
  ++ @329 GOTO 4.19
  ++ @330 GOTO 4.20
END


IF ~~ THEN BEGIN 4.19
  SAY @331
  = @333
  = @334
  ++ @335 GOTO 4.22
  ++ @336 GOTO 4.23
END


IF ~~ THEN BEGIN 4.20
  SAY @332
  = @333
  = @334
  ++ @335 GOTO 4.22
  ++ @336 GOTO 4.23
END


IF ~~ THEN BEGIN 4.21
  SAY @333
  = @334
  ++ @335 GOTO 4.22
  ++ @336 GOTO 4.23
END

IF ~~ THEN BEGIN 4.22
  SAY @337
  = @338
  ++ @339 GOTO 4.24
  ++ @340 GOTO 4.25
END

IF ~~ THEN BEGIN 4.23
  SAY @341
  = @342
  = @343
  = @349
  = @350
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 4.24
  SAY @344
  = @345
  = @346
  = @349
  = @350
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 4.25
  SAY @347
  = @348
  = @349
  = @350
  IF ~~ THEN DO ~SetGlobal("JWCastRestTalk1","GLOBAL",2)~ EXIT
END


//// Talk 4 - Talk in Cloakwood temple

IF ~Global("JWCastCloak","GLOBAL",1)~ THEN BEGIN 5.0
  SAY @400
  = @401
  ++ @402 GOTO 5.1
  ++ @403 GOTO 5.2
  ++ @404 GOTO 5.3
END

IF ~~ THEN BEGIN 5.1
  SAY @405
  = @408
  = @409
  = @410
  ++ @411 GOTO 5.4
  ++ @412 GOTO 5.5
  ++ @413 GOTO 5.12
END

IF ~~ THEN BEGIN 5.2
  SAY @406
  = @408
  = @409
  = @410
  ++ @411 GOTO 5.4
  ++ @412 GOTO 5.5
  ++ @413 GOTO 5.12
END

IF ~~ THEN BEGIN 5.3
  SAY @407
  IF ~~ THEN DO ~SetGlobal("JWCastCloak","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 5.4
  SAY @414
  = @415
  ++ @416 GOTO 5.6
  ++ @417 GOTO 5.12
END

IF ~~ THEN BEGIN 5.5
  SAY @418
  = @419
  ++ @416 GOTO 5.6
  ++ @417 GOTO 5.12
END

IF ~~ THEN BEGIN 5.6
  SAY @420
  ++ @421 GOTO 5.7
  ++ @422 GOTO 5.8
  ++ @423 GOTO 5.9
END

IF ~~ THEN BEGIN 5.7
  SAY @424
  = @425
  = @436
  = @437
IF ~~ THEN DO ~SetGlobal("JWCastCloak","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 5.8
  SAY @426
  = @427
  = @436
  = @437
IF ~~ THEN DO ~SetGlobal("JWCastCloak","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 5.9
  SAY @428
  = @429
  = @430
  ++ @431 GOTO 5.10
  ++ @432 GOTO 5.11
  ++ @433 GOTO 5.12
END

IF ~~ THEN BEGIN 5.10
  SAY @434
  = @436
  = @437
IF ~~ THEN DO ~SetGlobal("JWCastCloak","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 5.11
  SAY @435
  = @436
  = @437
IF ~~ THEN DO ~SetGlobal("JWCastCloak","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 5.12
  SAY @436
  = @437
IF ~~ THEN DO ~SetGlobal("JWCastCloak","GLOBAL",2)~ EXIT
END



//// Honorary Ring of Sune Talk

IF ~Global("JWCastRingTalk","GLOBAL",2)~ THEN BEGIN 10.0
  SAY @1520
  = @1521
  ++ @1522 GOTO 10.1
  ++ @1523 GOTO 10.2
  ++ @1524 GOTO 10.3
END

IF ~~ THEN BEGIN 10.1
  SAY @1527
  = @1528
  = @1529
  ++ @1530 GOTO 10.4
  ++ @1531 GOTO 10.5
  ++ @1532 GOTO 10.6
END

IF ~~ THEN BEGIN 10.2
  SAY @1526
  = @1528
  = @1529
  ++ @1530 GOTO 10.4
  ++ @1531 GOTO 10.5
  ++ @1532 GOTO 10.6
END

IF ~~ THEN BEGIN 10.3
  SAY @1525
  IF ~~ THEN DO ~SetGlobal("JWCastRingTalk","GLOBAL",3)~ EXIT
END

IF ~~ THEN BEGIN 10.4
  SAY @1534
  = @1535
  = @1537
  = @1538
  IF ~~ THEN DO ~SetGlobal("JWCastRingTalk","GLOBAL",3)~ EXIT
END

IF ~~ THEN BEGIN 10.5
  SAY @1536
  = @1537
  = @1538
  IF ~~ THEN DO ~SetGlobal("JWCastRingTalk","GLOBAL",3)~ EXIT
END

IF ~~ THEN BEGIN 10.6
  SAY @1533
  IF ~~ THEN DO ~SetGlobal("JWCastRingTalk","GLOBAL",2)~ EXIT
END

//// Edwin Complaint Talk

IF ~Global("JWEdwinJoinTalk","GLOBAL",2)~ THEN BEGIN 11.0
  SAY @1540
  = @1541
  ++ @1543 GOTO 11.1
  ++ @1544 GOTO 11.2
  ++ @1545 GOTO 11.3
END

IF ~~ THEN BEGIN 11.1
  SAY @1546
  = @1547
  ++ @1548 GOTO 11.4
  ++ @1549 GOTO 11.5
END

IF ~~ THEN BEGIN 11.2
  SAY @1547
  ++ @1548 GOTO 11.4
  ++ @1549 GOTO 11.5
END

IF ~~ THEN BEGIN 11.3
  SAY @1550
  = @1551
  IF ~~ THEN DO ~SetGlobal("JWEdwinJoinTalk","GLOBAL",3)~ EXIT
END

IF ~~ THEN BEGIN 11.4
  SAY @1552
  ++ @1549 GOTO 11.5
END

IF ~~ THEN BEGIN 11.5
  SAY @1553
  = @1554
  = @1555
  IF ~~ THEN DO ~SetGlobal("JWEdwinJoinTalk","GLOBAL",3)~ EXIT
END


//////////////////////////////////////////////////
//// Elminster Encounter
//////////////////////////////////////////////////

IF ~Global("JWCastElmTalk","GLOBAL",1)~ THEN BEGIN 6.0
  SAY @480
  = @481
  = @482
IF ~~ THEN DO ~SetGlobal("JWCastElmTalk","GLOBAL",2)~ EXIT
END


//////////////////////////////////////////////////
// Kayra talks
//////////////////////////////////////////////////

//// Talk 1 - Player has the book

IF ~Global("JWCastKay1","GLOBAL",1)~ THEN BEGIN 8.0
  SAY @500
  = @501
  = @502
  ++ @503 GOTO 8.1
  ++ @504 GOTO 8.3
  ++ @505 GOTO 8.4
  ++ @506 GOTO 8.5
END


IF ~~ THEN BEGIN 8.1
  SAY @507
  ++ @508 GOTO 8.2
  ++ @509 GOTO 8.3
END


IF ~~ THEN BEGIN 8.2
  SAY @510
  = @515
  ++ @516 GOTO 8.6
  ++ @517 GOTO 8.7
  ++ @518 GOTO 8.8
END


IF ~~ THEN BEGIN 8.3
  SAY @511
  = @512
  = @515
  ++ @516 GOTO 8.6
  ++ @517 GOTO 8.7
  ++ @518 GOTO 8.8
END


IF ~~ THEN BEGIN 8.4
  SAY @513
  = @515
  ++ @516 GOTO 8.6
  ++ @517 GOTO 8.7
  ++ @518 GOTO 8.8
END


IF ~~ THEN BEGIN 8.5
  SAY @514
  = @515
  ++ @516 GOTO 8.6
  ++ @517 GOTO 8.7
  ++ @518 GOTO 8.8
END

IF ~~ THEN BEGIN 8.6
  SAY @519
  IF ~~ THEN DO ~SetGlobal("JWCastKay1","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 8.7
  SAY @520
  IF ~~ THEN DO ~SetGlobal("JWCastKay1","GLOBAL",2)~ EXIT
END

IF ~~ THEN BEGIN 8.8
  SAY @521
  IF ~~ THEN DO ~SetGlobal("JWCastKay1","GLOBAL",2)~ EXIT
END

//// Talk 2 - Entering Jovial Juggler

IF ~Global("JWCastKay2","GLOBAL",1)~ THEN BEGIN 9.0
  SAY @600
  = @650
  = @601
  ++ @602 GOTO 9.1
  ++ @603 GOTO 9.2
  ++ @604 GOTO 9.3
END

IF ~~ THEN BEGIN 9.1
  SAY @605
  = @606
  = @607
  ++ @608 GOTO 9.4
  ++ @609 GOTO 9.5
  ++ @610 GOTO 9.6
END

IF ~~ THEN BEGIN 9.2
  SAY @611
  = @612
  = @613
  ++ @614 GOTO 9.6
  ++ @615 GOTO 9.7
  ++ @616 GOTO 9.1
END

IF ~~ THEN BEGIN 9.3
  SAY @617
  = @618
  = @619
  ++ @620 GOTO 9.8
  ++ @621 GOTO 9.9
  ++ @622 GOTO 9.10
END

IF ~~ THEN BEGIN 9.4
  SAY @623
  = @624
  = @625
  ++ @626 GOTO 9.11
  ++ @627 GOTO 9.5
  ++ @628 GOTO 9.6
END

IF ~~ THEN BEGIN 9.5
  SAY @629
  = @630
  ++ @631 GOTO 9.11
  ++ @632 GOTO 9.9
END

IF ~~ THEN BEGIN 9.6
  SAY @633
  ++ @634 GOTO 9.10
  ++ @635 GOTO 9.9
END

IF ~~ THEN BEGIN 9.7
  SAY @636
  = @637
  ++ @638 GOTO 9.6
  ++ @639 GOTO 9.1
END

IF ~~ THEN BEGIN 9.8
  SAY @640
  = @641
  = @642
IF ~PartyHasItem("JWBook1")~ THEN DO ~EraseJournalEntry(@21) AddJournalEntry(@24,QUEST) TakePartyItem("JWBook1") SetGlobal("JWCastKay2","GLOBAL",2) SetGlobal("JWCastLeft","GLOBAL",1) LeaveParty() EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 9.9
  SAY @643
  = @641
  = @642
IF ~PartyHasItem("JWBook1")~ THEN DO ~EraseJournalEntry(@21) AddJournalEntry(@24,QUEST) TakePartyItem("JWBook1") SetGlobal("JWCastKay2","GLOBAL",2) SetGlobal("JWCastLeft","GLOBAL",1) LeaveParty() EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 9.10
  SAY @644
  = @641
  = @642
IF ~PartyHasItem("JWBook1")~ THEN DO ~EraseJournalEntry(@21) AddJournalEntry(@24,QUEST) TakePartyItem("JWBook1") SetGlobal("JWCastKay2","GLOBAL",2) SetGlobal("JWCastLeft","GLOBAL",1) LeaveParty() EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 9.11
  SAY @645
  = @646
  = @647
  = @648
  = @649
IF ~PartyHasItem("JWBook1")~ THEN DO ~GiveItem("JWBook1",Myself) SetGlobal("JWCastKay2","GLOBAL",2) SetGlobal("JWCastKeepBook","GLOBAL",1)~ EXIT
END


//// Talk 3 - Player gives book to Kayra, Casterlynne in party.

IF ~Global("JWCastKay1","GLOBAL",3)~ THEN BEGIN 12.0
  SAY @660
  = @661
  ++ @662 GOTO 8.1
  ++ @663 GOTO 8.3
END


IF ~~ THEN BEGIN 12.1
  SAY @664
  = @665
  = @666
IF ~~ THEN DO ~SetGlobal("JWCastLeft","GLOBAL",1) LeaveParty() EscapeArea()~ EXIT
END


//////////////////////////////////////////////////
// BG1 Chapter5 Leave Talk
//////////////////////////////////////////////////

IF ~Global("JWCastLeaveTalk","GLOBAL",1)~ THEN BEGIN 15.0
  SAY @1500
  = @1501
  = @1502
  ++ @1503 GOTO 15.1
  ++ @1504 GOTO 15.1
  ++ @1505 GOTO 15.2
END

IF ~~ THEN BEGIN 15.1
  SAY @1506
  = @1507
IF ~~ THEN DO ~TakePartyItem("JWBook1") SetGlobal("JWCastLeaveTalk","GLOBAL",2) SetGlobal("JWCastLeft","GLOBAL",1) SetGlobal("JWCastKeepBook","GLOBAL",1) LeaveParty() EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 15.2
  SAY @1508
  = @1509
IF ~~ THEN DO ~TakePartyItem("JWBook1") SetGlobal("JWCastLeaveTalk","GLOBAL",2) SetGlobal("JWCastLeft","GLOBAL",1) SetGlobal("JWCastKeepBook","GLOBAL",1) LeaveParty() EscapeArea()~ EXIT
END

