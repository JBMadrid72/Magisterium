BEGIN JWOJov

IF ~NumberOfTimesTalkedTo(0)~ THEN BEGIN 1
SAY @700
= @701
 +~Global("JWGUARDTALK","GLOBAL",0)~+ @702 GOTO 1.1
 +~Global("JWGUARDTALK","GLOBAL",1)~+ @703 GOTO 1.2
END

IF ~!NumberOfTimesTalkedTo(0) !PartyHasItem("JWBook1") !Global("JWKayraJob1","Global",1)~ THEN BEGIN 1.01
SAY @706
 ++ @735 GOTO 1.3
END

IF ~!NumberOfTimesTalkedTo(0) Global("JWKayraJob1","Global",1)~ THEN BEGIN 1.02
SAY @706
 +~Global("JWCAST-JOINED","GLOBAL",1) InParty("JWCAST") PartyHasItem("JWBook1")~+ @704 DO ~TakePartyItem("JWBook1") EraseJournalEntry(@21) AddJournalEntry(@23,QUEST_DONE) GivePartyGold(100) AddexperienceParty(150) SetGlobal("JWKayraJob1","Global",3)~ GOTO 1.4   // Casterlunne joined, Gives book to Kayra
 +~Global("JWCAST-JOINED","GLOBAL",1) InParty("JWCAST") PartyHasItem("JWBook1")~+ @705 DO ~EraseJournalEntry(@21) AddJournalEntry(@22,QUEST_DONE) SetGlobal("JWKCConflict","Global",1)~ GOTO 1.6         // Casterlunne joined, doesnt give book to Kayra
 +~Global("JWCAST-JOINED","GLOBAL",1) !InParty("JWCAST") PartyHasItem("JWBook1")~+ @704 DO ~TakePartyItem("JWBook1") EraseJournalEntry(@21) AddJournalEntry(@23,QUEST_DONE) GivePartyGold(100) AddexperienceParty(150) SetGlobal("JWKayraJob1","Global",3)~ GOTO 1.5 // Casterlunne joined but no longer in party, Gives book to Kayra
 +~Global("JWCAST-JOINED","GLOBAL",1) !InParty("JWCAST") !PartyHasItem("JWBook1")~+ @705 DO ~EraseJournalEntry(@21) AddJournalEntry(@22,QUEST_DONE) SetGlobal("JWKCConflict","Global",1)~ GOTO 1.7     // Casterlunne joined but no longer in party, Doesnt give book to Kayra
 +~Global("JWCAST-JOINED","GLOBAL",0) !PartyHasItem("JWBook1")~+ @705 DO ~EraseJournalEntry(@21) AddJournalEntry(@22,QUEST_DONE) SetGlobal("JWKCConflict","Global",1)~ GOTO 1.20  // Casterlunne never joined, Doesnt give book to Kayra
 +~Global("JWCAST-JOINED","GLOBAL",0) PartyHasItem("JWBook1")~+ @704 DO ~EraseJournalEntry(@21) AddJournalEntry(@23,QUEST_DONE) SetGlobal("JWKCConflict","Global",1)~ GOTO 1.30 // Casterlunne never joined, gives book to Kayra
END

IF ~~ THEN BEGIN 1.1
SAY @707
= @709
IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.2
SAY @708
= @709
IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.3
SAY @736
IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.4
SAY @710
= @711
= @712
= @713
= @714
= @715
= @716
IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.5
SAY @710
= @711
= @713
= @714
= @715
= @716
IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.6
SAY @717
= @720
= @721
 ++ @722 GOTO 1.63
 ++ @723 GOTO 1.63
END

IF ~~ THEN BEGIN 1.61
SAY @718
= @721
 ++ @722 GOTO 1.63
 ++ @723 GOTO 1.63
END

IF ~~ THEN BEGIN 1.62
SAY @719
= @721
 ++ @722 GOTO 1.63
 ++ @723 GOTO 1.63
END

IF ~~ THEN BEGIN 1.63
SAY @728
 ++ @723 GOTO 1.8
 ++ @730 GOTO 1.9
END

IF ~~ THEN BEGIN 1.7
SAY @724
= @725
 ++ @726 GOTO 1.61
 ++ @727 GOTO 1.62
END

IF ~~ THEN BEGIN 1.8
SAY @731
= @733
= @734
= @737
IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.9
SAY @732
= @733
= @734
= @737
IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.20
SAY @728
 ++ @723 GOTO 1.8
 ++ @730 GOTO 1.9
END

IF ~~ THEN BEGIN 1.30
SAY @710
= @711
= @713
= @714
= @715
= @716
IF ~~ THEN DO ~EscapeArea()~ EXIT
END
