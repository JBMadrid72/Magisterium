BEGIN JWOBal

IF ~NumberOfTimesTalkedTo(0)~ THEN BEGIN 1.0
SAY @800
= @801
= @802
    +~!Global("JWCastLeft","GLOBAL",1) !Global("TalkedToAlatos","GLOBAL",1)~+ @803 GOTO 1.11
    +~!Global("JWCastLeft","GLOBAL",1) Global("TalkedToAlatos","GLOBAL",1)~+ @803 GOTO 1.1
    +~Global("JWCastLeft","GLOBAL",1)~+ @803 GOTO 1.15
    +~Global("JWCastLeft","GLOBAL",1)~+ @804 GOTO 1.2
    +~!Global("JWCastLeft","GLOBAL",1)~+ @804 GOTO 1.25
END

IF ~!NumberOfTimesTalkedTo(0) Global("TalkedToAlatos","GLOBAL",1) !Global("JWKayraObal1","GLOBAL",1)~ THEN BEGIN 1.01
SAY @862
= @826
  +~!Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.41
  +~!Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.42
  +~Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.43
  +~Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.44
END

IF ~!NumberOfTimesTalkedTo(0) Global("JWKayraObal1","GLOBAL",1)~ THEN BEGIN 1.02
SAY @865
    +~!Global("JWBalGuildJob","GLOBAL",1)~+ @866 GOTO 1.03
    +~GlobalTimerExpired("AlatosTenDayTimer","GLOBAL")~+ @881 GOTO 1.07
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") !Dead("Helshara") !Dead("Delorna") !Dead("Ithmeera")~+ @880 GOTO 1.04
    +~!PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71")~+ @878 GOTO 1.05
    +~PartyHasItem("MISC69") !PartyHasItem("MISC70") PartyHasItem("MISC71")~+ @878 GOTO 1.05
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") !PartyHasItem("MISC71")~+ @878 GOTO 1.05
    +~!PartyHasItem("MISC69") !PartyHasItem("MISC70") PartyHasItem("MISC71")~+ @878 GOTO 1.05
    +~PartyHasItem("MISC69") !PartyHasItem("MISC70") !PartyHasItem("MISC71")~+ @878 GOTO 1.05
    +~!PartyHasItem("MISC69") PartyHasItem("MISC70") !PartyHasItem("MISC71")~+ @878 GOTO 1.05
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") Dead("Helshara") Dead("Delorna") Dead("Ithmeera")~+ @879 GOTO 1.06
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") !Dead("Helshara") Dead("Delorna") Dead("Ithmeera")~+ @879 GOTO 1.06
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") Dead("Helshara") !Dead("Delorna") Dead("Ithmeera")~+ @879 GOTO 1.06
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") Dead("Helshara") Dead("Delorna") !Dead("Ithmeera")~+ @879 GOTO 1.06
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") !Dead("Helshara") Dead("Delorna") !Dead("Ithmeera")~+ @879 GOTO 1.06
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") Dead("Helshara") !Dead("Delorna") !Dead("Ithmeera")~+ @879 GOTO 1.06
    +~PartyHasItem("MISC69") PartyHasItem("MISC70") PartyHasItem("MISC71") !Dead("Helshara") !Dead("Delorna") Dead("Ithmeera")~+ @879 GOTO 1.06
END

IF ~~ THEN BEGIN 1.03
SAY @866 IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.04
SAY @870
= @871
= @872
= @873
IF ~~ THEN DO ~SetGlobal("JWBalGuildJob","GLOBAL",1) EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.05
SAY @874
= @875
= @876
= @877
IF ~~ THEN DO ~SetGlobal("JWBalGuildJob","GLOBAL",1) EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.06
SAY @883
= @876
= @877
= @882
IF ~~ THEN DO ~SetGlobal("JWBalGuildJob","GLOBAL",1) EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.07
SAY @884
= @876
= @877
= @882
IF ~~ THEN DO ~SetGlobal("JWBalGuildJob","GLOBAL",1) EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.1
SAY @805
= @808
= @826
  +~!Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.41
  +~!Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.42
  +~Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.43
  +~Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.44
END

IF ~~ THEN BEGIN 1.11
SAY @805
= @808
= @822
= @823
= @824
= @825 IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.15
SAY @805
= @809
= @810
    +~Global("JWCastLeft","GLOBAL",1) !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.3
    +~Global("JWCastLeft","GLOBAL",1) Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.31
    +~!Global("JWCastLeft","GLOBAL",1) PartyHasItem("JWBook1") !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.32
    +~!Global("JWCastLeft","GLOBAL",1) PartyHasItem("JWBook1") Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.33
    +~!Global("JWCastLeft","GLOBAL",1) !PartyHasItem("JWBook1") !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.34
    +~!Global("JWCastLeft","GLOBAL",1) !PartyHasItem("JWBook1") Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.35
    +~!Global("TalkedToAlatos","GLOBAL",1)~+ @812 GOTO 1.36
    +~Global("TalkedToAlatos","GLOBAL",1)~+ @812 GOTO 1.37
END

IF ~~ THEN BEGIN 1.2
SAY @806
= @808
    +~Global("JWCastLeft","GLOBAL",1) !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.3
    +~Global("JWCastLeft","GLOBAL",1) Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.31
    +~!Global("JWCastLeft","GLOBAL",1) PartyHasItem("JWBook1") !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.32
    +~!Global("JWCastLeft","GLOBAL",1) PartyHasItem("JWBook1") Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.33
    +~!Global("JWCastLeft","GLOBAL",1) !PartyHasItem("JWBook1") !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.34
    +~!Global("JWCastLeft","GLOBAL",1) !PartyHasItem("JWBook1") Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.35
    +~!Global("TalkedToAlatos","GLOBAL",1)~+ @812 GOTO 1.36
    +~Global("TalkedToAlatos","GLOBAL",1)~+ @812 GOTO 1.37
END

IF ~~ THEN BEGIN 1.25
SAY @806
= @809
= @810
    +~Global("JWCastLeft","GLOBAL",1) Global("TalkedToAlatos","GLOBAL",0)~+ @811 GOTO 1.3
    +~Global("JWCastLeft","GLOBAL",1) Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.31
    +~!Global("JWCastLeft","GLOBAL",1) PartyHasItem("JWBook1") !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.32
    +~!Global("JWCastLeft","GLOBAL",1) PartyHasItem("JWBook1") Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.33
    +~!Global("JWCastLeft","GLOBAL",1) !PartyHasItem("JWBook1") !Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.34
    +~!Global("JWCastLeft","GLOBAL",1) !PartyHasItem("JWBook1") Global("TalkedToAlatos","GLOBAL",1)~+ @811 GOTO 1.35
    +~!Global("TalkedToAlatos","GLOBAL",1)~+ @812 GOTO 1.36
    +~Global("TalkedToAlatos","GLOBAL",1)~+ @812 GOTO 1.37
END

IF ~~ THEN BEGIN 1.3
SAY @813
= @814
= @815
= @867
= @822
= @823
= @824
= @825 IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.31
SAY @813
= @814
= @815
= @867
= @826
  +~!Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.41
  +~!Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.42
  +~Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.43
  +~Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.44
END

IF ~~ THEN BEGIN 1.32
SAY @816
= @817
= @818
= @867
= @822
= @823
= @824
= @825 IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.33
SAY @816
= @817
= @818
= @867
= @826
  +~!Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.41
  +~!Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.42
  +~Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.43
  +~Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.44
END

IF ~~ THEN BEGIN 1.34
SAY @816
= @817
= @819
= @867
= @822
= @823
= @824
= @825 IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.35
SAY @816
= @817
= @819
= @867
= @826
  +~!Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.41
  +~!Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.42
  +~Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.43
  +~Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.44
END

IF ~~ THEN BEGIN 1.36
SAY @820
= @821
= @822
= @823
= @824
= @825 IF ~~ EXIT
END

IF ~~ THEN BEGIN 1.37
SAY @816
= @817
= @819
= @826
  +~!Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.41
  +~!Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.42
  +~Global("JWTraveRob","GLOBAL",3)~+ @827 GOTO 1.43
  +~Global("JWTraveRob","GLOBAL",3)~+ @828 GOTO 1.44
END

IF ~~ THEN BEGIN 1.41
SAY @829
= @810
= @863
= @864
  +~!Global("JWTraveRob","GLOBAL",3)~+ @833 GOTO 1.5
  +~Global("JWTraveRob","GLOBAL",3)~+ @834 GOTO 1.51
  ++ @835 GOTO 1.52
END

IF ~~ THEN BEGIN 1.42
SAY @830
= @863
= @864
  +~!Global("JWTraveRob","GLOBAL",3)~+ @833 GOTO 1.5
  +~Global("JWTraveRob","GLOBAL",3)~+ @834 GOTO 1.51
  ++ @835 GOTO 1.52
END

IF ~~ THEN BEGIN 1.43
SAY @831
= @847
= @848
  +~!Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.60
  +~Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.61
  +~!Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.62
  +~Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.63
  +~!Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.64
  +~Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.65
END

IF ~~ THEN BEGIN 1.44
SAY @832
= @847
= @848
  +~!Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.60
  +~Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.61
  +~!Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.62
  +~Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.63
  +~!Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.64
  +~Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.65
END

IF ~~ THEN BEGIN 1.5
SAY @836
= @837
= @839
= @840
  ++ @841  GOTO 1.57
  ++ @842  GOTO 1.55
  ++ @843  GOTO 1.56
END

IF ~~ THEN BEGIN 1.51
SAY @839
= @840
  ++ @841  GOTO 1.57
  ++ @842  GOTO 1.55
  ++ @843  GOTO 1.56
END

IF ~~ THEN BEGIN 1.52
SAY @838
= @839
= @840
  ++ @841  GOTO 1.57
  ++ @842  GOTO 1.55
  ++ @843  GOTO 1.56
END

IF ~~ THEN BEGIN 1.55
SAY @845
= @847
= @848
  +~!Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.60
  +~Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.61
  +~!Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.62
  +~Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.63
  +~!Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.64
  +~Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.65
END

IF ~~ THEN BEGIN 1.56
SAY @846
= @847
= @848
  +~!Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.60
  +~Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.61
  +~!Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.62
  +~Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.63
  +~!Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.64
  +~Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.65
END

IF ~~ THEN BEGIN 1.57
SAY @844
= @846
= @847
= @848
  +~!Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.60
  +~Global("JWTraveRob","GLOBAL",3)~+ @849  GOTO 1.61
  +~!Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.62
  +~Global("JWTraveRob","GLOBAL",3)~+ @850  GOTO 1.63
  +~!Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.64
  +~Global("JWTraveRob","GLOBAL",3)~+ @851  GOTO 1.65
END

IF ~~ THEN BEGIN 1.60
SAY @852
= @857
= @858
= @859
IF ~~ THEN DO ~SetGlobal("JWKayraObal1","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN 1.61
SAY @853
= @860
= @861
IF ~~ THEN DO ~SetGlobal("JWKayraObal1","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN 1.62
SAY @854
= @857
= @858
= @859
IF ~~ THEN DO ~SetGlobal("JWKayraObal1","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN 1.63
SAY @854
= @860
= @861
IF ~~ THEN DO ~SetGlobal("JWKayraObal1","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN 1.64
SAY @855
= @856
= @857
= @858
= @859
IF ~~ THEN DO ~SetGlobal("JWKayraObal1","GLOBAL",1)~ EXIT
END

IF ~~ THEN BEGIN 1.65
SAY @855
= @856
= @860
= @861
IF ~~ THEN DO ~SetGlobal("JWKayraObal1","GLOBAL",1)~ EXIT
END
