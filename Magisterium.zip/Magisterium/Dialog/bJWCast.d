BEGIN BJWCast

//////////
// Interjections
//////////

// Kayra quest

INTERJECT_COPY_TRANS JWKAYRA 12 JWCastKayra1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@120
== JWKAYRA @121
END

INTERJECT_COPY_TRANS JWKAYRA 15 JWCastKayra2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@120
== JWKAYRA @121
END

INTERJECT_COPY_TRANS JWOJOV 9 JWCastKayra3
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@123
== JWOJOV @124
END

// Edwin joins

INTERJECT_COPY_TRANS EDWIN 1 JWCastEdw1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@551
== EDWIN @552 //Plays sound file EDWIN33
END

// Casterylnne Interject Gellena

INTERJECT_COPY_TRANS GELLAN 0 JWCastGell
== JWCast IF ~!InParty("JWCast") NumTimesTalkedTo(0)~ THEN
@118
== GELLAN @119
END

// IRON11 Cloakwood Temple Guard

INTERJECT_COPY_TRANS IRON11 0 JWCastIRO1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@620
== IRON11 @621 DO ~SetGlobal("JWIRON11met","GLOBAL",1)~
END


// IMOEN TEMPLE OF NASHKEL

INTERJECT_COPY_TRANS JWCast 79 ImoenTemple1
== BIMOEN @549
END


// NALIN TEMPLE OF NASHKEL

INTERJECT_COPY_TRANS NALIN 1 JWCastNalin1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@550
== NALIN @564
END

// Neera Meeting Beregost

INTERJECT_COPY_TRANS NEEKANDO 3 JWCastNeek1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@553
END

INTERJECT_COPY_TRANS NEEKANDO 4 JWCastNeek2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@562
== NEEKANDO @563
END

// Rasaad Join Interjections1

INTERJECT_COPY_TRANS RASAAD 24 JWCastRas1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@565
END

// Rasaad Join Interjections2

INTERJECT_COPY_TRANS RASAAD 21 JWCastRas2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@566
== RASAAD @567
== JWCastJ @568
END

// Dynaheir and Edwin Fight

INTERJECT_COPY_TRANS DYNAHE 8 JWCastDyn1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@569
END

// Dynaheir and Edwin Fight2

INTERJECT_COPY_TRANS DYNAHE 19 JWCastDyn2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@570
END

// Neera Adoy Talk

INTERJECT_COPY_TRANS NEERAJ 30 JWCastNead1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@554
== BNEERA @555
END

INTERJECT_COPY_TRANS NEERAJ 31 JWCastNead2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@554
== BNEERA @555
END

INTERJECT_COPY_TRANS NEADOY 0 JWCastNead3
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@556
== NEADOY @557
END

INTERJECT_COPY_TRANS NEADOY 1 JWCastNead4
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@556
== NEADOY @557
END

INTERJECT_COPY_TRANS NEADOY 3 JWCastNead5
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@558
END

// Melicamp Talks

INTERJECT_COPY_TRANS MELICA 13 JWCastMeli1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@559
== MELICA @560 // Plays sound file CHICK06
END

INTERJECT_COPY_TRANS MELICA 22 JWCastMeli2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@561
END

// ARCHAEOLOGICAL SITE
// Charleston Nibbs  Interaction

INTERJECT_COPY_TRANS CHARLE 10 JWCastChar1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@572
END

// Digger Interaction

INTERJECT_COPY_TRANS CHARLE 7 JWCastChar2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@573
END

// Elminster Interaction

INTERJECT_COPY_TRANS ELMIN2 0 JWCastElm2
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast") Global("JWCastElmTalk","GLOBAL",0)~ THEN
@622
== ELMIN2 @623
== ELMIN2 @624 DO ~SetGlobal("JWCastElmTalk","GLOBAL",1)~
END

INTERJECT_COPY_TRANS ELMIN3 0 JWCastElm3
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast") Global("JWCastElmTalk","GLOBAL",0)~ THEN
@622
== ELMIN3 @623
== ELMIN3 @624 DO ~SetGlobal("JWCastElmTalk","GLOBAL",1)~
END

// Messenger Interaction

INTERJECT_COPY_TRANS JWCMESS 0 JWCastMes1
== JWCastJ IF ~InParty("JWCast") InMyArea("JWCast")~ THEN
@625
== JWCMESS @626
== JWCastJ @627
== JWCMESS @628
END


//////////
// CHAIN PARTY BANTERS
//////////

// Dynaheir

CHAIN IF ~InParty("Dynaheir")
See("Dynaheir")
InParty("JWCast")
See("JWCast")
!StateCheck("Dynaheir",CD_STATE_NOTVALID)
!StateCheck("JWCast",CD_STATE_NOTVALID)
CombatCounter(0)
!See([ENEMY])
Global("JWCastDynaheir1","GLOBAL",0)~ THEN BDYNAH JWCastDynaheir1
@578 // Thou art a follower of The Hidden
DO ~SetGlobal("JWCastDynaheir1","GLOBAL",1)~
== BJWCast @579 // Yes, you are correct
== BDYNAH @580 // Tis warming to be in the company
== BJWCast @581 // Dynaheir, I would appreciate
== BDYNAH @582 // Does give me strength to hear
EXIT


// Neera

CHAIN IF ~InParty("Neera")
See("Neera")
InParty("JWCast")
See("JWCast")
!StateCheck("Neera",CD_STATE_NOTVALID)
!StateCheck("JWCast",CD_STATE_NOTVALID)
CombatCounter(0)
!See([ENEMY])
Global("JWCastNeera1","GLOBAL",0)~ THEN BJWCast JWCastNeera1
@601 // NEERA!
DO ~SetGlobal("JWCastNeera1","GLOBAL",1)~
== BNEERA @602 // No, not again! I..I'm sorry
== BJWCast @603 // Well, I didnt like the color
== BNEERA @604 // I..I'm sorry
== BJWCast @605 // (Laughs) Travelling with you
EXIT

CHAIN IF ~InParty("Neera")
See("Neera")
InParty("JWCast")
See("JWCast")
!StateCheck("Neera",CD_STATE_NOTVALID)
!StateCheck("JWCast",CD_STATE_NOTVALID)
CombatCounter(0)
!See([ENEMY])
Global("JWCastNeera2","GLOBAL",0)~ THEN BJWCast JWCastNeera2
@606 // This idea of yours, its very
DO ~SetGlobal("JWCastNeera2","GLOBAL",1)~
== BNEERA @607 // You really think so?
== BJWCast @608 // Yes. You wild mages
== BNEERA @609 // If I just new where to
== BJWCast @610 // It takes courage, a little magic
== BNEERA @611 // Yeah! You are right. Thanks Cas!
EXIT


// Montaran/Xzar

CHAIN IF ~InParty("MONTARON")
See("MONTARON")
InParty("XZAR")
See("XZAR")
InParty("JWCast")
See("JWCast")
!StateCheck("MONTARON",CD_STATE_NOTVALID)
!StateCheck("JWCast",CD_STATE_NOTVALID)
CombatCounter(0)
!See([ENEMY])
Global("JWCastMont1","GLOBAL",0)~ THEN BJWCast JWCastMont1
@616 // I'm about to start
DO ~SetGlobal("JWCastMont1","GLOBAL",1)~
== BXZAR @617 // laughs
== BMONTA @617 // laughs
== BXZAR @618 // laughs and falls on floor
== BJWCast @619 // Why do we bother
EXIT


// Viconia BattleCry

//CHAIN IF ~InParty("VICONIA")
//See("VICONIA")
//InParty("JWCast")
//Global("JWCastVicFight","GLOBAL",1)
//Global("JWCastVicFightDone","GLOBAL",0)
//!StateCheck("VICONIA",CD_STATE_NOTVALID)
//!StateCheck("JWCast",CD_STATE_NOTVALID)
//CombatCounter(0)
//!See([ENEMY])
//Global("JWCastVic1","GLOBAL",0)~ THEN BJWCAST JWCastVic1
//~You. Drow� You worship the goddess Shar? Tell me!~
//DO ~SetGlobal("JWCastVic1","GLOBAL",1)
//SetGlobal("JWCastVicFightDone","GLOBAL",1)
//SetGlobal("JWCastVicFight","GLOBAL",2)~
//== BVICON ~Yes. And I suggest you mind your tone.~
//== BJWCAST ~We shall see!~
//EXIT
