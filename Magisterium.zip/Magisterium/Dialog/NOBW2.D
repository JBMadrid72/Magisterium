BEGIN ~NOBW2~

IF ~TRUE() Global("JWNOBL2","Global",0)~ THEN BEGIN 0
  SAY ~Who in the Seven Heavens are all of you?! Why, you didn't even have the common decency to remove your footwear. Look at all of the mud you've tracked over the house! Get out! Leave! Begone!~
  IF ~~ THEN EXIT
END

IF ~TRUE() Global("JWNOBL2","Global",1)~ THEN BEGIN 1.5
  SAY ~I couldn't help but overhear your conversation with my husband. I do apologise for his manner. He does enjoy making a spectacle of himself.~
  IF ~~ THEN REPLY ~We were asking about a book. The Magisterium. Perhaps you can help us?~ DO ~~
    GOTO 4
  IF ~~ THEN REPLY ~Your husband was rather uncooperative. Are you any different?~ DO ~~
    GOTO 3
END


IF ~StateCheck(Myself,STATE_CHARMED)~ THEN BEGIN 1
  SAY ~Even though it is not decent for me to mingle with those beneath my station, I find that you possess a certain irresistible charm. I am willing to tell whatever you wish to hear. Perhaps you'd like to know about the last ball I attended. It was wondrous, I was at the forefront of everyone's mind.~
  IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 2
  SAY ~I'll not have you near me!~
  IF ~~ THEN EXIT
END

IF ~~ THEN BEGIN 3
  SAY ~How very direct of you. I rather admire that, though I would advise against speaking to my husband in quite that manner. He has a dreadful temper when crossed.~
  IF ~~ THEN REPLY ~The book is called 'The Magisterium'. Perhaps you can help us?~ DO ~~
    GOTO 5
END

IF ~~ THEN BEGIN 4
  SAY ~Oh, that dreadful old book! My husband is terribly proud of his collection, though I doubt he has read half of it. I believe it is kept in the library, among his other precious volumes.~
  IF ~~ THEN REPLY ~Would you help us get it?~ DO ~~
    GOTO 5
END

IF ~~ THEN BEGIN 5
  SAY ~Well, I certainly cannot simply hand you the keys to the library. But I could perhaps find a reason to keep the servants occupied for a little while. You didn't hear that from me, of course.~
  IF ~~ THEN DO ~SetGlobal("JWNOBL2","Global",2)~ EXIT
END