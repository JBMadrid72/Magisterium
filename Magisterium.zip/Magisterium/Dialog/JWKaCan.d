BEGIN JWKaCan

IF ~True() NumberOfTimesTalkedTo(0)~ THEN BEGIN 1.0
SAY @51
= @52
= @53
IF ~~  THEN DO ~SetGlobal("JWVoiceKayraScene","GLOBAL",2)~ EXTERN ~JWVOICE~ 0
END

IF ~Global("JWVoiceKayraScene","GLOBAL",2) !Alignment(Player1,MASK_EVIL)~ THEN BEGIN 1.1
SAY @60
IF ~~ THEN DO ~EscapeArea()~ EXIT
END

IF ~Global("JWVoiceKayraScene","GLOBAL",2) Alignment(Player1,MASK_EVIL)~ THEN BEGIN 1.11
SAY @61
    ++ @62 GOTO 1.15
END

IF ~~ THEN BEGIN 1.15
SAY @63
    ++ @66 GOTO 1.2
END

IF ~~ THEN BEGIN 1.2
SAY @67
    ++ @68 GOTO 1.3
END

IF ~~ THEN BEGIN 1.3
SAY @69
= @70
IF ~~ THEN DO ~SetGlobal("JWVoiceKayraScene","GLOBAL",3) EscapeArea()~ EXIT
END

IF ~~ THEN BEGIN 1.4
SAY @65
    ++ @66 GOTO 1.5
END

IF ~~ THEN BEGIN 1.5
SAY @67
    ++ @71 GOTO 1.6
END

IF ~~ THEN BEGIN 1.6
SAY @72
= @73
IF ~~ THEN DO ~SetGlobal("JWVoiceKayraScene","GLOBAL",3) EscapeArea()~ EXIT
END
